<?php
use App\Models\User;
use App\Models\Wishlist;
use App\Models\Profile;
use App\Models\Kos;

class FavoritController extends Controller{
public function showHomepage()
    {
        $userId = auth()->id();
        $user = User::find($userId);
        $wishlist = Wishlist::with('kos')->where('id_user', $userId)->get();
        $profile = Profile::where('id_user', $userId)->first();
        $profileDefault = Profile::where('id_user', $userId)->count();

        return view('homepage', compact('user', 'wishlist', 'profile', 'profileDefault'));
    }
}